# SSMS Query Shortcuts for VS Code

Replicates the exact SSMS "Query Shortcuts" behavior in VS Code:

- Select a table name (or place your cursor on one)
- Press the shortcut key (e.g. **Ctrl+3**)
- The SQL query runs immediately — **your code is NOT modified**

## Default Shortcuts

| Shortcut | SQL Template |
|----------|-------------|
| Alt+F1   | `EXEC sp_help '{0}'` |
| Ctrl+1   | `EXEC sp_who` |
| Ctrl+2   | `EXEC sp_lock` |
| Ctrl+3   | `SELECT TOP 1000 * FROM {0}` |
| Ctrl+4   | `SELECT COUNT(1) AS Nb FROM {0}` |
| Ctrl+5..0 | *(empty — configure your own)* |

`{0}` = selected text or word under cursor.

## Installation

1. Copy the `ssms-query-shortcuts` folder to your VS Code extensions directory:
   - **Windows**: `%USERPROFILE%\.vscode\extensions\ssms-query-shortcuts`
   - **macOS**: `~/.vscode/extensions/ssms-query-shortcuts`
   - **Linux**: `~/.vscode/extensions/ssms-query-shortcuts`

2. Restart VS Code

3. Make sure the **mssql** extension is installed for query execution

## Customizing Shortcuts

Open **Settings** (Ctrl+,) and search for `ssmsShortcuts.shortcuts`.

You can edit the JSON directly in `settings.json`:

```json
"ssmsShortcuts.shortcuts": {
    "altF1": "EXEC sp_help '{0}'",
    "ctrl1": "EXEC sp_who",
    "ctrl2": "EXEC sp_lock",
    "ctrl3": "SELECT TOP 1000 * FROM {0}",
    "ctrl4": "SELECT COUNT(1) AS Nb FROM {0}",
    "ctrl5": "SELECT DISTINCT * FROM {0}",
    "ctrl6": "SELECT @@VERSION",
    "ctrl7": "",
    "ctrl8": "",
    "ctrl9": "",
    "ctrl0": ""
}
```

## How It Works

Unlike the snippet-based approach, this extension:
- Opens a **temporary SQL tab** with the generated query
- **Executes it automatically** via the mssql extension
- **Never modifies your original code**

This matches exactly how SSMS query shortcuts work.

## Requirements

- VS Code 1.80+
- [mssql extension](https://marketplace.visualstudio.com/items?itemName=ms-mssql.mssql) for query execution
