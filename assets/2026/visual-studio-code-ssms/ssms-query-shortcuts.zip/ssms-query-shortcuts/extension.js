const vscode = require('vscode');

/**
 * SSMS Query Shortcuts for VS Code
 * 
 * Replicates the SSMS "Query Shortcuts" behavior:
 * - Select a table name (or place cursor on a word)
 * - Press the shortcut (e.g. Ctrl+3)
 * - The SQL runs immediately in the results pane
 * - Your editor code is NOT modified
 * - NO new tab is opened
 */

function activate(context) {
    const shortcutKeys = [
        'altF1', 'ctrl1', 'ctrl2', 'ctrl3', 'ctrl4',
        'ctrl5', 'ctrl6', 'ctrl7', 'ctrl8', 'ctrl9', 'ctrl0'
    ];

    for (const key of shortcutKeys) {
        const disposable = vscode.commands.registerCommand(
            `ssmsShortcuts.${key}`,
            () => runQueryShortcut(key)
        );
        context.subscriptions.push(disposable);
    }

    console.log('SSMS Query Shortcuts extension activated');
}

/**
 * Gets the selected text, or the word under the cursor if nothing is selected.
 */
function getSelectedTextOrWord(editor) {
    const selection = editor.selection;

    if (!selection.isEmpty) {
        return editor.document.getText(selection);
    }

    // No selection: get the word under cursor (like SSMS does)
    const wordRange = editor.document.getWordRangeAtPosition(selection.active);
    if (wordRange) {
        return editor.document.getText(wordRange);
    }

    return '';
}

/**
 * Builds the SQL from the template and runs it in the CURRENT editor.
 * No new tab is opened.
 * 
 * Strategy:
 *   1. Save cursor position and current selection
 *   2. Append the generated query at the end of the document
 *   3. Select only that appended query
 *   4. Run it via mssql (which executes the selected text)
 *   5. Wait briefly for mssql to capture the query
 *   6. Undo the insertion to restore the original document
 *   7. Restore original cursor position
 */
async function runQueryShortcut(shortcutKey) {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
        vscode.window.showWarningMessage('No active editor');
        return;
    }

    // Read the template from settings
    const config = vscode.workspace.getConfiguration('ssmsShortcuts');
    const shortcuts = config.get('shortcuts', {});
    const template = shortcuts[shortcutKey] || '';

    if (!template) {
        vscode.window.showInformationMessage(
            `SSMS shortcut "${shortcutKey}" is not configured. Set it in Settings → SSMS Query Shortcuts.`
        );
        return;
    }

    // Get selected text or word under cursor
    const selectedText = getSelectedTextOrWord(editor);

    // If template uses {0} but no text is selected/found
    if (template.includes('{0}') && !selectedText) {
        vscode.window.showWarningMessage(
            'No text selected and no word under cursor. Select a table name first.'
        );
        return;
    }

    // Build the final SQL
    const sql = template.replace(/\{0\}/g, selectedText);

    // Save original cursor/selection
    const originalSelection = editor.selection;
    const doc = editor.document;
    const lastLine = doc.lineAt(doc.lineCount - 1);
    const endPosition = lastLine.range.end;

    // Append the query at the end with a separator
    const separator = '\n-- [SSMS Shortcut]\n';
    const appendedText = separator + sql;

    const success = await editor.edit(editBuilder => {
        editBuilder.insert(endPosition, appendedText);
    });

    if (!success) {
        vscode.window.showErrorMessage('Failed to inject query');
        return;
    }

    // Select only the appended SQL line(s), not the separator comment
    const newLastLine = doc.lineAt(doc.lineCount - 1);
    const sqlStartLine = endPosition.line + 2; // skip blank + separator
    const sqlStartPos = new vscode.Position(sqlStartLine, 0);
    const sqlEndPos = newLastLine.range.end;

    editor.selection = new vscode.Selection(sqlStartPos, sqlEndPos);

    // Run the selected query via mssql
    try {
        await vscode.commands.executeCommand('mssql.runQuery');
    } catch {
        try {
            await vscode.commands.executeCommand('mssql.runSelectedStatement');
        } catch {
            vscode.window.showInformationMessage(
                `Could not auto-execute. Query: ${sql}`
            );
        }
    }

    // Wait for mssql to capture the query before we remove it
    await new Promise(resolve => setTimeout(resolve, 500));

    // Undo the insertion to restore the original document
    await vscode.commands.executeCommand('undo');

    // Restore original cursor position
    editor.selection = originalSelection;
}

function deactivate() {}

module.exports = { activate, deactivate };
